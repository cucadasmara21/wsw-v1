/**
 * Vitest setup file
 * Import jest-dom matchers for better assertions
 */
import '@testing-library/jest-dom'
