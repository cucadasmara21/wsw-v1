# Minimal services package for local dev and tests
